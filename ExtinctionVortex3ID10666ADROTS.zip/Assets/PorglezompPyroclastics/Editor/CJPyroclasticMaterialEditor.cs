using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

public class CJPyroclasticMaterialEditor : MaterialEditor {
	public override void OnInspectorGUI() {
		EditorGUILayout.LabelField("Edit the properties using the ExplosionMat script.");	
	}
}